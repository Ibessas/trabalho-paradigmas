package Data

enum class Gosto {
    RUIM, NORMAL, BOM

}
