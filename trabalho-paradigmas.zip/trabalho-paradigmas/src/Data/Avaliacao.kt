package Data

data class Avaliacao(
    val id: String,
    val refeicao: Refeicao,
    val nota: Gosto
)
